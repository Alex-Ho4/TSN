Group 6 - The Social Network

to compile after installing opensplice: type 'make' and then './tsn'
